declare var $:JQuery;



interface JQueryElement {
    /** ts */
    click(callback:Function):JQueryElement;
    css(name:string,value:string):JQueryElement;
    css(name:string):string;
}

interface JQuery {
    (callback:Function):void;
    (selector:string):JQueryElement;
    ajax(option:AjaxOption);
}

interface AjaxOption {
    url:string;
    success:Function;
}
