$(function(){

});

var height =  $("#id").click(function(){
    console.log("Click");
}).css("height","20px").css("height")

var option:AjaxOption = {
    url:"http://domain.com/data",

    success:function(data,xhr) {

    }
}
$.ajax(option);