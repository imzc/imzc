import fs = require('fs');

/**
 * 读取文本文件,返回打开文本的字符串内容，若失败，返回"".
 * @param path 要打开的文件路径
 */
export function read(path) {
    
    var text:string;
    try {
        text = fs.readFileSync(path, 'utf-8');
    }
    catch (err0) {
        return "";
    }

    return text;
}