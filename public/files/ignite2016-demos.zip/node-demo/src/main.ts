import http = require('http');
import {read} from './file';
var port = process.env.port || 1337;
http.createServer(function (req, res) {
    res.writeHead(200, { 'Content-Type': 'text/plain' });
    var content = read("./data.txt");
    res.end(content);
}).listen(port);

console.log(`Server Started! Please visit http://127.0.0.1:${port}`);