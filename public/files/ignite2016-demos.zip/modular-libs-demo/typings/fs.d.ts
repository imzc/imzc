import * as f from 'fs';

declare module "fs" {
    export function test():f.FSWatcher;
}

