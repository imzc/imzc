
export function save(path:string,data:string|Buffer):void;